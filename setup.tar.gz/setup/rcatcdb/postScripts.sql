SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /home/oracle/setup/rcatcdb/postScripts.log append
UPDATE sys.USER$ set SPARE6=NULL;
alter session set "_oracle_script"=TRUE;
execute dbms_datapump_utl.create_default_dir;
commit;
alter session set "_oracle_script"=FALSE;
connect "SYS"/"&&sysPassword" as SYSDBA
host /u01/app/oracle/product/19.3.0/dbhome_1/perl/bin/perl /u01/app/oracle/product/19.3.0/dbhome_1/rdbms/admin/catcon.pl -n 1 -l /home/oracle/setup/rcatcdb -v  -b ordlib  -U "SYS"/"&&sysPassword" /u01/app/oracle/product/19.3.0/dbhome_1/ord/im/admin/ordlib.sql;
connect "SYS"/"&&sysPassword" as SYSDBA
create or replace directory XMLDIR as '/u01/app/oracle/product/19.3.0/dbhome_1/rdbms/xml';
create or replace directory XSDDIR as '/u01/app/oracle/product/19.3.0/dbhome_1/rdbms/xml/schema';
@/u01/app/oracle/product/19.3.0/dbhome_1/rdbms/admin/utlfixdirs.sql;
connect "SYS"/"&&sysPassword" as SYSDBA
connect "SYS"/"&&sysPassword" as SYSDBA
@/u01/app/oracle/product/19.3.0/dbhome_1/rdbms/admin/execocm.sql;
execute dbms_qopatch.replace_logscrpt_dirs;
host /u01/app/oracle/product/19.3.0/dbhome_1/perl/bin/perl /u01/app/oracle/product/19.3.0/dbhome_1/rdbms/admin/catcon.pl -n 1 -l /home/oracle/setup/rcatcdb -v  -b execemx  -U "SYS"/"&&sysPassword" /u01/app/oracle/product/19.3.0/dbhome_1/rdbms/admin/execemx.sql;
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /home/oracle/setup/rcatcdb/postDBCreation.log append
