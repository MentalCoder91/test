#!/bin/sh

OLD_UMASK=`umask`
umask 0027
mkdir -p /u01/app/oracle
mkdir -p /u01/app/oracle/admin/rcatcdb/adump
mkdir -p /u01/app/oracle/admin/rcatcdb/dpdump
mkdir -p /u01/app/oracle/admin/rcatcdb/pfile
mkdir -p /u01/app/oracle/audit
mkdir -p /u01/app/oracle/cfgtoollogs/dbca/rcatcdb
mkdir -p /u01/app/oracle/fast_recovery_area
mkdir -p /u01/app/oracle/fast_recovery_area/RCATCDB
mkdir -p /u01/app/oracle/oradata/RCATCDB
mkdir -p /u01/app/oracle/oradata/RCATCDB/pdbseed
mkdir -p /u01/app/oracle/oradata/RCATCDB/rcatpdb
mkdir -p /u01/app/oracle/product/19.3.0/dbhome_1/dbs
umask ${OLD_UMASK}
PERL5LIB=$ORACLE_HOME/rdbms/admin:$PERL5LIB; export PERL5LIB
ORACLE_SID=rcatcdb; export ORACLE_SID
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/perl/bin:$PATH; export PATH
echo You should Add this entry in the /etc/oratab: rcatcdb:/u01/app/oracle/product/19.3.0/dbhome_1:Y
/u01/app/oracle/product/19.3.0/dbhome_1/bin/sqlplus /nolog @/home/oracle/setup/rcatcdb/rcatcdb.sql
