connect target sys/&1;
 
run
{
set command id  to 'PDB$SEED';
RESTORE FOREIGN DATAFILE  2 FORMAT '/u01/app/oracle/oradata/RCATCDB/pdbseed/system01.dbf',4 FORMAT '/u01/app/oracle/oradata/RCATCDB/pdbseed/sysaux01.dbf',9 FORMAT '/u01/app/oracle/oradata/RCATCDB/pdbseed/undotbs01.dbf' FROM BACKUPSET  '/u01/app/oracle/product/19.3.0/dbhome_1/assistants/dbca/templates/pdbseed.dfb' ;
}
exit;
