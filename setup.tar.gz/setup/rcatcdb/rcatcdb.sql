set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
ACCEPT pdbAdminPassword CHAR PROMPT 'Enter new password for PDBADMIN: ' HIDE
host /u01/app/oracle/product/19.3.0/dbhome_1/bin/orapwd file=/u01/app/oracle/product/19.3.0/dbhome_1/dbs/orapwrcatcdb force=y format=12
@/home/oracle/setup/rcatcdb/CloneRmanRestore.sql
@/home/oracle/setup/rcatcdb/cloneDBCreation.sql
@/home/oracle/setup/rcatcdb/plug_PDBSeed.sql
@/home/oracle/setup/rcatcdb/postScripts.sql
@/home/oracle/setup/rcatcdb/lockAccount.sql
@/home/oracle/setup/rcatcdb/postDBCreation.sql
@/home/oracle/setup/rcatcdb/PDBCreation.sql
@/home/oracle/setup/rcatcdb/plug_rcatpdb.sql
@/home/oracle/setup/rcatcdb/postPDBCreation_rcatpdb.sql
