SET VERIFY OFF
set echo on
spool /home/oracle/setup/rcatcdb/PDBCreation.log append
