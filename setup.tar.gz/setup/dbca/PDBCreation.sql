SET VERIFY OFF
set echo on
spool /home/oracle/setup/dbca/PDBCreation.log append
