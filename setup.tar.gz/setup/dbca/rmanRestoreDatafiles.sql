connect target sys/&1;
 
CATALOG START WITH   '/u01/app/oracle/product/19.3.0/dbhome_1/assistants/dbca/templates//Seed_Database.dfb'  NOPROMPT  ;

RUN {  

set newname for datafile 1 to  '/u01/app/oracle/oradata/ORCLCDB/system01.dbf' ; 

set newname for datafile 3 to  '/u01/app/oracle/oradata/ORCLCDB/sysaux01.dbf' ; 

set newname for datafile 4 to  '/u01/app/oracle/oradata/ORCLCDB/undotbs01.dbf' ; 

set newname for datafile 7 to  '/u01/app/oracle/oradata/ORCLCDB/users01.dbf' ; 

restore datafile 1; 

restore datafile 3; 

restore datafile 4; 

restore datafile 7; }
