SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /home/oracle/setup/dbca/plugDatabase2R.log append
spool /home/oracle/setup/dbca/plugDatabase2R.log append
host mkdir -p /u01/app/oracle/oradata/ORCLCDB/orclpdb2;
select d.name||'|'||t.name from v$datafile d,V$TABLESPACE t where d.con_id=2 and d.ts#=t.ts# and d.con_id=t.con_id;
select d.name||'|'||t.name from v$tempfile d,V$TABLESPACE t where d.con_id=2 and d.ts#=t.ts# and d.con_id=t.con_id;
CREATE PLUGGABLE DATABASE orclpdb2 ADMIN USER PDBADMIN IDENTIFIED BY "&&pdbadminPassword" ROLES=(CONNECT)  file_name_convert=('/u01/app/oracle/oradata/ORCLCDB/pdbseed',
'/u01/app/oracle/oradata/ORCLCDB/orclpdb2')  STORAGE ( MAXSIZE UNLIMITED MAX_SHARED_TEMP_SIZE UNLIMITED);
alter pluggable database orclpdb2 open;
alter system register;
