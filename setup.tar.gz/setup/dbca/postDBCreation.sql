SET VERIFY OFF
spool /home/oracle/setup/dbca/postDBCreation.log append
host /u01/app/oracle/product/19.3.0/dbhome_1/OPatch/datapatch -skip_upgrade_check -db orclcdb;
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
create spfile='/u01/app/oracle/product/19.3.0/dbhome_1/dbs/spfileorclcdb.ora' FROM pfile='/home/oracle/setup/dbca/init.ora';
connect "SYS"/"&&sysPassword" as SYSDBA
host /u01/app/oracle/product/19.3.0/dbhome_1/perl/bin/perl /u01/app/oracle/product/19.3.0/dbhome_1/rdbms/admin/catcon.pl -n 1 -l /home/oracle/setup/dbca -v  -b utlrp  -U "SYS"/"&&sysPassword" /u01/app/oracle/product/19.3.0/dbhome_1/rdbms/admin/utlrp.sql;
select comp_id, status from dba_registry;
execute dbms_swrf_internal.cleanup_database(cleanup_local => FALSE);
commit;
shutdown immediate;
connect "SYS"/"&&sysPassword" as SYSDBA
startup ;
spool off
