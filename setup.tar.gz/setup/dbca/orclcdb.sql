set verify off
ACCEPT sysPassword CHAR PROMPT 'Enter new password for SYS: ' HIDE
ACCEPT systemPassword CHAR PROMPT 'Enter new password for SYSTEM: ' HIDE
ACCEPT pdbAdminPassword CHAR PROMPT 'Enter new password for PDBADMIN: ' HIDE
host /u01/app/oracle/product/19.3.0/dbhome_1/bin/orapwd file=/u01/app/oracle/product/19.3.0/dbhome_1/dbs/orapworclcdb force=y format=12
@/home/oracle/setup/dbca/CloneRmanRestore.sql
@/home/oracle/setup/dbca/cloneDBCreation.sql
@/home/oracle/setup/dbca/plug_PDBSeed.sql
@/home/oracle/setup/dbca/postScripts.sql
@/home/oracle/setup/dbca/lockAccount.sql
@/home/oracle/setup/dbca/postDBCreation.sql
@/home/oracle/setup/dbca/PDBCreation.sql
@/home/oracle/setup/dbca/plug_orclpdb1.sql
@/home/oracle/setup/dbca/postPDBCreation_orclpdb1.sql
@/home/oracle/setup/dbca/plug_orclpdb2.sql
@/home/oracle/setup/dbca/postPDBCreation_orclpdb2.sql
