SET VERIFY OFF
connect "SYS"/"&&sysPassword" as SYSDBA
set echo on
spool /home/oracle/setup/dbca/plugDatabase1R.log append
spool /home/oracle/setup/dbca/plugDatabase1R.log append
host mkdir -p /u01/app/oracle/oradata/ORCLCDB/orclpdb1;
select d.name||'|'||t.name from v$datafile d,V$TABLESPACE t where d.con_id=2 and d.ts#=t.ts# and d.con_id=t.con_id;
select d.name||'|'||t.name from v$tempfile d,V$TABLESPACE t where d.con_id=2 and d.ts#=t.ts# and d.con_id=t.con_id;
CREATE PLUGGABLE DATABASE orclpdb1 ADMIN USER PDBADMIN IDENTIFIED BY "&&pdbadminPassword" ROLES=(CONNECT)  file_name_convert=('/u01/app/oracle/oradata/ORCLCDB/pdbseed',
'/u01/app/oracle/oradata/ORCLCDB/orclpdb1')  STORAGE ( MAXSIZE UNLIMITED MAX_SHARED_TEMP_SIZE UNLIMITED);
alter pluggable database orclpdb1 open;
alter system register;
