connect target sys/&1;
 
crosscheck copy;
delete expired copy
exit;
